import React, { useState } from 'react';

const AndroidDB = () => {
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const devicesPerPage = 5;
  
  const devices = [
    {
      id: 1,
      model: "X9Pro",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Corp",  // Изменено с CorpTech на Corp
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 2,
      model: "A5Max",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Data",  // Изменено с DataSys на Data
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 3,
      model: "Z3Edge",
      softwareVersion: "",
      lastUpdate: "",
      organization: "FutureSoft",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 4,
      model: "TX-42",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Mobile",  // Изменено с MobileInc на Mobile
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 5,
      model: "M7",
      softwareVersion: "",
      lastUpdate: "",
      organization: "TechGroup",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 6,
      model: "V300",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Digital",  // Изменено с DigitalCom на Digital
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 7,
      model: "CodeX5",
      softwareVersion: "",
      lastUpdate: "",
      organization: "GlobalTech",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 8,
      model: "Nova3",
      softwareVersion: "",
      lastUpdate: "",
      organization: "SmartSolutions",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 9,
      model: "Alpha7",
      softwareVersion: "",
      lastUpdate: "",
      organization: "NextGen",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 10,
      model: "QuantumX",
      softwareVersion: "",
      lastUpdate: "",
      organization: "InnovateX",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    // Остальные 10 устройств оставим пустыми
    {
      id: 11,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 12,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 13,
      model: "SkyLine",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 14,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Cloud9",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 15,
      model: "Photon",
      softwareVersion: "",
      lastUpdate: "",
      organization: "NetSys",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 16,
      model: "MaxPro",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 17,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Data5",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 18,
      model: "Quantum",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 19,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Alpha7",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 20,
      model: "Nova8",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Beta3",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    }
  ];

  // Функция для фильтрации устройств по поисковому запросу
  const filteredDevices = devices.filter(device => {
    const searchLower = searchQuery.toLowerCase();
    return (
      device.model.toLowerCase().includes(searchLower) ||
      device.organization.toLowerCase().includes(searchLower)
    );
  });

  // Вычисляем индексы для отображения на текущей странице с учетом фильтрации
  const indexOfLastDevice = currentPage * devicesPerPage;
  const indexOfFirstDevice = indexOfLastDevice - devicesPerPage;
  const currentDevices = filteredDevices.slice(indexOfFirstDevice, indexOfLastDevice);
  
  // Общее количество страниц с учетом фильтрации
  const totalPages = Math.ceil(filteredDevices.length / devicesPerPage);

  const styles = {
    container: {
      fontFamily: "'Segoe UI', 'Roboto', sans-serif",
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '30px',
      backgroundColor: '#ffffff',
      color: '#333333',
    },
    header: {
      color: '#2c3e50',
      borderBottom: '2px solid #e0e0e0',
      paddingBottom: '20px',
      marginBottom: '40px',
      textAlign: 'center',
      fontWeight: '300',
      letterSpacing: '1px'
    },
    deviceList: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
      gap: '25px',
      marginBottom: '40px'
    },
    deviceCard: {
      backgroundColor: '#ffffff',
      padding: '25px',
      borderRadius: '10px',
      boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      border: '1px solid #f0f0f0',
      ':hover': {
        transform: 'translateY(-5px)',
        boxShadow: '0 8px 15px rgba(0,0,0,0.1)',
        borderColor: '#e0e0e0'
      }
    },
    searchContainer: {
      margin: '30px 0',
      display: 'flex',
      justifyContent: 'center'
    },
    searchInput: {
      width: '100%',
      maxWidth: '500px',
      padding: '12px 15px',
      border: '1px solid #e0e0e0',
      borderRadius: '6px',
      fontSize: '16px',
      transition: 'border-color 0.3s',
      ':focus': {
        outline: 'none',
        borderColor: '#2c3e50'
      }
    },
    pagination: {
      display: 'flex',
      justifyContent: 'center',
      margin: '30px 0',
      flexWrap: 'wrap'
    },
    pageButton: {
      backgroundColor: '#f5f5f5',
      color: '#2c3e50',
      padding: '10px 18px',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      margin: '5px',
      fontWeight: '500',
      transition: 'background-color 0.3s, color 0.3s'
    },
    activePageButton: {
      backgroundColor: '#2c3e50',
      color: 'white',
      padding: '10px 18px',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      margin: '5px',
      fontWeight: '500'
    },
    detailView: {
      backgroundColor: '#ffffff',
      padding: '40px',
      borderRadius: '12px',
      boxShadow: '0 6px 15px rgba(0,0,0,0.08)',
      maxWidth: '800px',
      margin: '0 auto'
    },
    detailRow: {
      margin: '15px 0',
      padding: '15px 0',
      borderBottom: '1px solid #f0f0f0',
      display: 'flex',
      alignItems: 'center'
    },
    label: {
      fontWeight: '600',
      color: '#2c3e50',
      width: '220px',
      display: 'inline-block',
      fontSize: '15px'
    },
    backButton: {
      backgroundColor: '#f5f5f5',
      color: '#2c3e50',
      padding: '12px 24px',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      margin: '20px 0',
      fontWeight: '500',
      transition: 'background-color 0.3s, color 0.3s',
      display: 'flex',
      alignItems: 'center',
      ':hover': {
        backgroundColor: '#e0e0e0'
      }
    },
    headerContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px'
    },
    detailHeader: {
      color: '#2c3e50',
      borderBottom: '2px solid #e0e0e0',
      paddingBottom: '15px',
      marginBottom: '30px',
      fontWeight: '500'
    }
  };

  // Функции для пагинации
  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePageClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div style={styles.container}>
      {/* Шапка с кнопкой возврата на главную */}
      <div style={styles.headerContainer}>
        <h1 style={styles.header}>ANDROID DATABASE SYSTEM</h1>
        <button 
          style={styles.backButton}
          onClick={() => {
            setSelectedDevice(null);
            setCurrentPage(1);
          }}
        >
          Back to Home
        </button>
      </div>
      
      {/* Поле поиска */}
      <div style={styles.searchContainer}>
        <input
          type="text"
          placeholder="Search by model or organization..."
          style={styles.searchInput}
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setCurrentPage(1);
          }}
        />
      </div>
      
      {!selectedDevice ? (
        <>
          <div style={styles.deviceList}>
            {currentDevices.map(device => (
              <div 
                key={device.id}
                style={styles.deviceCard}
                onClick={() => setSelectedDevice(device)}
              >
                <h3 style={{margin: '0 0 15px 0', fontWeight: '500'}}>{device.model || `Android ${device.id}`}</h3>
                <p style={{color: '#666666', margin: '0', fontSize: '14px'}}>
                  {device.organization || "Organization not specified"}
                </p>
              </div>
            ))}
          </div>
          
          {/* Элементы управления пагинацией */}
          <div style={styles.pagination}>
            <button 
              style={styles.pageButton}
              onClick={handlePreviousPage}
              disabled={currentPage === 1}
            >
              Previous
            </button>
            
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <button
                key={page}
                style={currentPage === page ? styles.activePageButton : styles.pageButton}
                onClick={() => handlePageClick(page)}
              >
                {page}
              </button>
            ))}
            
            <button 
              style={styles.pageButton}
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
            >
              Next
            </button>
          </div>
        </>
      ) : (
        <div style={styles.detailView}>
          <button 
            style={styles.backButton}
            onClick={() => setSelectedDevice(null)}
          >
            ← Back to Home
          </button>
          
          <h2 style={styles.detailHeader}>
            {selectedDevice.model || "Model not specified"}
          </h2>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Software Version:</span>
            <span style={{color: '#555555'}}>{selectedDevice.softwareVersion}</span>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Last Update:</span>
            <span style={{color: '#555555'}}>{selectedDevice.lastUpdate}</span>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Organization:</span>
            <span style={{color: '#555555'}}>{selectedDevice.organization}</span>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Organization Website:</span>
            <a 
              href={selectedDevice.organizationWebsite}
              style={{color: '#3498db', textDecoration: 'none'}}
              target="_blank"
              rel="noopener noreferrer"
            >
              {selectedDevice.organizationWebsite || "Link not specified"}
            </a>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Work Area:</span>
            <span style={{color: '#555555'}}>{selectedDevice.workArea}</span>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Purpose/Task:</span>
            <span style={{color: '#555555'}}>{selectedDevice.purpose}</span>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Capabilities:</span>
            <span style={{color: '#555555'}}>{selectedDevice.capabilities}</span>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Location:</span>
            <span style={{color: '#555555'}}>{selectedDevice.location}</span>
          </div>
          
          <div style={styles.detailRow}>
            <span style={styles.label}>Work Period\lifespan:</span>
            <span style={{color: '#555555'}}>{selectedDevice.workPeriod}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default AndroidDB;