import React, { useState } from 'react';

const AndroidDB = () => {
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const devicesPerPage = 6;
  
  const devices = [
    {
      id: 1,
      model: "X9Pro",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Corp",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 2,
      model: "A5Max",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Data",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 3,
      model: "Z3Edge",
      softwareVersion: "",
      lastUpdate: "",
      organization: "FutureSoft",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 4,
      model: "TX-42",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Mobile",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 5,
      model: "M7",
      softwareVersion: "",
      lastUpdate: "",
      organization: "TechGroup",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 6,
      model: "V300",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Digital",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    // Остальные устройства остаются пустыми
    {
      id: 7,
      model: "CodeX5",
      softwareVersion: "",
      lastUpdate: "",
      organization: "GlobalTech",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 8,
      model: "Nova3",
      softwareVersion: "",
      lastUpdate: "",
      organization: "SmartSolutions",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 9,
      model: "Alpha7",
      softwareVersion: "",
      lastUpdate: "",
      organization: "NextGen",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 10,
      model: "QuantumX",
      softwareVersion: "",
      lastUpdate: "",
      organization: "InnovateX",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 11,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 12,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 13,
      model: "SkyLine",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 14,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Cloud9",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 15,
      model: "Photon",
      softwareVersion: "",
      lastUpdate: "",
      organization: "NetSys",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 16,
      model: "MaxPro",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 17,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Data5",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 18,
      model: "Quantum",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 19,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Alpha7",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 20,
      model: "Nova8",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Beta3",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    }
  ];

  // Фильтрация и пагинация остаются без изменений
  const filteredDevices = devices.filter(device => {
    const searchLower = searchQuery.toLowerCase();
    return (
      device.model.toLowerCase().includes(searchLower) ||
      device.organization.toLowerCase().includes(searchLower)
    );
  });

  const indexOfLastDevice = currentPage * devicesPerPage;
  const indexOfFirstDevice = indexOfLastDevice - devicesPerPage;
  const currentDevices = filteredDevices.slice(indexOfFirstDevice, indexOfLastDevice);
  const totalPages = Math.ceil(filteredDevices.length / devicesPerPage);

  const styles = {
    container: {
      fontFamily: "'Helvetica Neue', Arial, sans-serif",
      maxWidth: '1440px',
      margin: '0 auto',
      padding: '40px 20px',
      backgroundColor: '#ffffff',
      color: '#333333',
    },
    header: {
      color: '#2c3e50',
      borderBottom: '3px solid #e0e0e0',
      paddingBottom: '25px',
      marginBottom: '50px',
      textAlign: 'center',
      fontWeight: '300',
      letterSpacing: '2px',
      fontSize: '2.5em'
    },
    mainLayout: {
      display: 'flex',
      flexDirection: 'column',
      gap: '40px'
    },
    searchContainer: {
      display: 'flex',
      justifyContent: 'center',
      margin: '30px 0'
    },
    searchInput: {
      width: '100%',
      maxWidth: '600px',
      padding: '15px 20px',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      fontSize: '16px',
      transition: 'all 0.3s ease',
      ':focus': {
        outline: 'none',
        borderColor: '#2c3e50',
        boxShadow: '0 0 0 2px rgba(44, 62, 80, 0.1)'
      }
    },
    deviceGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
      gap: '30px',
      margin: '20px 0'
    },
    deviceCard: {
      backgroundColor: '#ffffff',
      padding: '25px',
      borderRadius: '12px',
      boxShadow: '0 6px 15px rgba(0,0,0,0.05)',
      cursor: 'pointer',
      transition: 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)',
      border: '1px solid #f5f5f5',
      ':hover': {
        transform: 'translateY(-5px)',
        boxShadow: '0 10px 20px rgba(0,0,0,0.08)',
        borderColor: '#e0e0e0'
      }
    },
    cardContent: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px'
    },
    cardTitle: {
      margin: '0',
      fontSize: '1.2em',
      color: '#2c3e50',
      fontWeight: '500'
    },
    cardSubtitle: {
      margin: '0',
      color: '#666666',
      fontSize: '0.9em'
    },
    pagination: {
      display: 'flex',
      justifyContent: 'center',
      margin: '40px 0',
      flexWrap: 'wrap',
      gap: '8px'
    },
    pageButton: {
      backgroundColor: '#f5f5f5',
      color: '#2c3e50',
      padding: '10px 18px',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontWeight: '500',
      transition: 'all 0.2s',
      ':hover': {
        backgroundColor: '#e0e0e0'
      },
      ':disabled': {
        opacity: 0.5,
        cursor: 'not-allowed'
      }
    },
    activePageButton: {
      backgroundColor: '#2c3e50',
      color: 'white',
      padding: '10px 18px',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontWeight: '500'
    },
    detailView: {
      backgroundColor: '#ffffff',
      padding: '40px',
      borderRadius: '16px',
      boxShadow: '0 8px 25px rgba(0,0,0,0.08)',
      maxWidth: '800px',
      margin: '20px auto',
      border: '1px solid #f0f0f0'
    },
    detailHeader: {
      color: '#2c3e50',
      borderBottom: '2px solid #e0e0e0',
      paddingBottom: '20px',
      marginBottom: '30px',
      fontWeight: '500',
      fontSize: '1.8em'
    },
    detailGrid: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '25px',
      margin: '20px 0'
    },
    detailRow: {
      margin: '15px 0',
      padding: '15px 0',
      borderBottom: '1px solid #f0f0f0',
      display: 'flex',
      alignItems: 'center'
    },
    label: {
      fontWeight: '600',
      color: '#2c3e50',
      width: '220px',
      fontSize: '15px'
    },
    value: {
      color: '#555555',
      fontSize: '15px'
    },
    backButton: {
      backgroundColor: '#f5f5f5',
      color: '#2c3e50',
      padding: '12px 24px',
      border: 'none',
      borderRadius: '8px',
      cursor: 'pointer',
      margin: '20px 0',
      fontWeight: '500',
      transition: 'all 0.3s',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      ':hover': {
        backgroundColor: '#e0e0e0',
        transform: 'translateX(-3px)'
      }
    }
  };

  // Рендеринг остается без изменений
  return (
    <div style={styles.container}>
      <h1 style={styles.header}>ANDROID DATABASE SYSTEM</h1>
      
      <div style={styles.mainLayout}>
        <div style={styles.searchContainer}>
          <input
            type="text"
            placeholder="Search by model or organization..."
            style={styles.searchInput}
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>
        
        {!selectedDevice ? (
          <>
            <div style={styles.deviceGrid}>
              {currentDevices.map(device => (
                <div 
                  key={device.id}
                  style={styles.deviceCard}
                  onClick={() => setSelectedDevice(device)}
                >
                  <div style={styles.cardContent}>
                    <h3 style={styles.cardTitle}>{device.model || `Android ${device.id}`}</h3>
                    <p style={styles.cardSubtitle}>
                      {device.organization || "Organization not specified"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div style={styles.pagination}>
              <button 
                style={styles.pageButton}
                onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1}
              >
                Previous
              </button>
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <button
                  key={page}
                  style={currentPage === page ? styles.activePageButton : styles.pageButton}
                  onClick={() => setCurrentPage(page)}
                >
                  {page}
                </button>
              ))}
              
              <button 
                style={styles.pageButton}
                onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                Next
              </button>
            </div>
          </>
        ) : (
          <div style={styles.detailView}>
            <button 
              style={styles.backButton}
              onClick={() => setSelectedDevice(null)}
            >
              ← Back to Home
            </button>
            
            <h2 style={styles.detailHeader}>
              {selectedDevice.model || "Model not specified"}
            </h2>
            
            <div style={styles.detailGrid}>
              <div style={styles.detailRow}>
                <span style={styles.label}>Software Version:</span>
                <span style={styles.value}>{selectedDevice.softwareVersion}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Last Update:</span>
                <span style={styles.value}>{selectedDevice.lastUpdate}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Organization:</span>
                <span style={styles.value}>{selectedDevice.organization}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Website:</span>
                <a 
                  href={selectedDevice.organizationWebsite}
                  style={{color: '#3498db', textDecoration: 'none'}}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {selectedDevice.organizationWebsite || "Link not specified"}
                </a>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Work Area:</span>
                <span style={styles.value}>{selectedDevice.workArea}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Purpose:</span>
                <span style={styles.value}>{selectedDevice.purpose}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Capabilities:</span>
                <span style={styles.value}>{selectedDevice.capabilities}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Location:</span>
                <span style={styles.value}>{selectedDevice.location}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Work Period\lifespan:</span>
                <span style={styles.value}>{selectedDevice.workPeriod}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AndroidDB;