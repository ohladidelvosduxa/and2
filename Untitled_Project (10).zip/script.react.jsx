import React, { useState } from 'react';

const AndroidDB = () => {
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const devicesPerPage = 6;
  
  const devices = [
    {
      id: 1,
      model: "X9Pro",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Corp",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 2,
      model: "A5Max",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Data",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 3,
      model: "Z3Edge",
      softwareVersion: "",
      lastUpdate: "",
      organization: "FutureSoft",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 4,
      model: "TX-42",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Mobile",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 5,
      model: "M7",
      softwareVersion: "",
      lastUpdate: "",
      organization: "TechGroup",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 6,
      model: "V300",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Digital",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    // Остальные устройства остаются пустыми
    {
      id: 7,
      model: "CodeX5",
      softwareVersion: "",
      lastUpdate: "",
      organization: "GlobalTech",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 8,
      model: "Nova3",
      softwareVersion: "",
      lastUpdate: "",
      organization: "SmartSolutions",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 9,
      model: "Alpha7",
      softwareVersion: "",
      lastUpdate: "",
      organization: "NextGen",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 10,
      model: "QuantumX",
      softwareVersion: "",
      lastUpdate: "",
      organization: "InnovateX",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 11,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 12,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 13,
      model: "SkyLine",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 14,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Cloud9",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 15,
      model: "Photon",
      softwareVersion: "",
      lastUpdate: "",
      organization: "NetSys",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 16,
      model: "MaxPro",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 17,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Data5",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 18,
      model: "Quantum",
      softwareVersion: "",
      lastUpdate: "",
      organization: "",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 19,
      model: "",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Alpha7",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    },
    {
      id: 20,
      model: "Nova8",
      softwareVersion: "",
      lastUpdate: "",
      organization: "Beta3",
      organizationWebsite: "",
      workArea: "",
      purpose: "",
      capabilities: "",
      location: "",
      workPeriod: ""
    }
  ];

  // Фильтрация и пагинация остаются без изменений
  const filteredDevices = devices.filter(device => {
    const searchLower = searchQuery.toLowerCase();
    return (
      device.model.toLowerCase().includes(searchLower) ||
      device.organization.toLowerCase().includes(searchLower)
    );
  });

  const indexOfLastDevice = currentPage * devicesPerPage;
  const indexOfFirstDevice = indexOfLastDevice - devicesPerPage;
  const currentDevices = filteredDevices.slice(indexOfFirstDevice, indexOfLastDevice);
  const totalPages = Math.ceil(filteredDevices.length / devicesPerPage);

  const styles = {
    container: {
      fontFamily: "'Inter', 'Roboto', sans-serif",
      maxWidth: '1280px',
      margin: '0 auto',
      padding: '30px 20px',
      backgroundColor: '#ffffff',
      color: '#212121',
    },
    header: {
      color: '#1a237e',
      borderBottom: '2px solid #e0e0e0',
      paddingBottom: '20px',
      marginBottom: '40px',
      textAlign: 'center',
      fontWeight: '500',
      letterSpacing: '1px',
      fontSize: '2.2em',
      textTransform: 'uppercase'
    },
    headerContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px'
    },
    backButton: {
      backgroundColor: '#f5f5f5',
      color: '#1a237e',
      padding: '10px 20px',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontWeight: '500',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      ':hover': {
        backgroundColor: '#e0e0e0'
      }
    },
    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      gap: '30px'
    },
    searchContainer: {
      display: 'flex',
      justifyContent: 'center',
      margin: '20px 0'
    },
    searchInput: {
      width: '100%',
      maxWidth: '500px',
      padding: '12px 16px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '15px',
      transition: 'border-color 0.3s',
      ':focus': {
        outline: 'none',
        borderColor: '#1a237e'
      }
    },
    cardGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
      gap: '20px',
      margin: '10px 0'
    },
    card: {
      backgroundColor: '#ffffff',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
      border: '1px solid #f0f0f0',
      cursor: 'pointer',
      transition: 'all 0.2s',
      ':hover': {
        boxShadow: '0 4px 8px rgba(0,0,0,0.08)',
        transform: 'translateY(-2px)'
      }
    },
    cardTitle: {
      margin: '0 0 10px 0',
      color: '#1a237e',
      fontWeight: '500',
      fontSize: '1.1em'
    },
    cardSubtitle: {
      margin: '0',
      color: '#616161',
      fontSize: '0.9em'
    },
    pagination: {
      display: 'flex',
      justifyContent: 'center',
      margin: '30px 0',
      gap: '8px'
    },
    pageButton: {
      backgroundColor: '#f5f5f5',
      color: '#424242',
      padding: '8px 14px',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      ':hover': {
        backgroundColor: '#e0e0e0'
      },
      ':disabled': {
        opacity: 0.5,
        cursor: 'not-allowed'
      }
    },
    activePageButton: {
      backgroundColor: '#1a237e',
      color: 'white',
      padding: '8px 14px',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500'
    },
    detailContainer: {
      backgroundColor: '#ffffff',
      padding: '30px',
      borderRadius: '8px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.06)',
      maxWidth: '800px',
      margin: '20px auto',
      border: '1px solid #f0f0f0'
    },
    detailHeader: {
      color: '#1a237e',
      borderBottom: '2px solid #e0e0e0',
      paddingBottom: '15px',
      marginBottom: '25px',
      fontWeight: '500',
      fontSize: '1.5em'
    },
    detailGrid: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '20px',
      margin: '20px 0'
    },
    detailRow: {
      margin: '12px 0',
      padding: '12px 0',
      borderBottom: '1px solid #f0f0f0',
      display: 'flex',
      alignItems: 'center'
    },
    label: {
      fontWeight: '600',
      color: '#424242',
      width: '180px',
      fontSize: '14px'
    },
    value: {
      color: '#616161',
      fontSize: '14px'
    }
  };

  // Рендеринг остается без изменений, но с обновленными стилями
  return (
    <div style={styles.container}>
      <div style={styles.headerContainer}>
        <h1 style={styles.header}>ANDROID DATABASE SYSTEM</h1>
        {selectedDevice && (
          <button 
            style={styles.backButton}
            onClick={() => setSelectedDevice(null)}
          >
            ← Back to Home
          </button>
        )}
      </div>
      
      <div style={styles.mainContent}>
        <div style={styles.searchContainer}>
          <input
            type="text"
            placeholder="Search by model or organization..."
            style={styles.searchInput}
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>
        
        {!selectedDevice ? (
          <>
            <div style={styles.cardGrid}>
              {currentDevices.map(device => (
                <div 
                  key={device.id}
                  style={styles.card}
                  onClick={() => setSelectedDevice(device)}
                >
                  <h3 style={styles.cardTitle}>{device.model || `Android ${device.id}`}</h3>
                  <p style={styles.cardSubtitle}>
                    {device.organization || "Organization not specified"}
                  </p>
                </div>
              ))}
            </div>
            
            <div style={styles.pagination}>
              <button 
                style={styles.pageButton}
                onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1}
              >
                Previous
              </button>
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <button
                  key={page}
                  style={currentPage === page ? styles.activePageButton : styles.pageButton}
                  onClick={() => setCurrentPage(page)}
                >
                  {page}
                </button>
              ))}
              
              <button 
                style={styles.pageButton}
                onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                Next
              </button>
            </div>
          </>
        ) : (
          <div style={styles.detailContainer}>
            <h2 style={styles.detailHeader}>
              {selectedDevice.model || "Model not specified"}
            </h2>
            
            <div style={styles.detailGrid}>
              <div style={styles.detailRow}>
                <span style={styles.label}>Software Version:</span>
                <span style={styles.value}>{selectedDevice.softwareVersion}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Last Update:</span>
                <span style={styles.value}>{selectedDevice.lastUpdate}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Organization:</span>
                <span style={styles.value}>{selectedDevice.organization}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Website:</span>
                <a 
                  href={selectedDevice.organizationWebsite}
                  style={{color: '#1a237e', textDecoration: 'none'}}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {selectedDevice.organizationWebsite || "Link not specified"}
                </a>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Work Area:</span>
                <span style={styles.value}>{selectedDevice.workArea}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Purpose:</span>
                <span style={styles.value}>{selectedDevice.purpose}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Capabilities:</span>
                <span style={styles.value}>{selectedDevice.capabilities}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Location:</span>
                <span style={styles.value}>{selectedDevice.location}</span>
              </div>
              
              <div style={styles.detailRow}>
                <span style={styles.label}>Work Period\lifespan:</span>
                <span style={styles.value}>{selectedDevice.workPeriod}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AndroidDB;